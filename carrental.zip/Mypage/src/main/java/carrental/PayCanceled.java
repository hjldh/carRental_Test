package carrental;

public class PayCanceled extends AbstractEvent {

    private Long id;
    private String contractId;
    private String payStatus;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }
    public String getPaystatus() {
        return payStatus;
    }

    public void setPaystatus(String payStatus) {
        this.payStatus = payStatus;
    }
}